import { useState, useEffect, useRef } from "react";
import { Plus, Minus, Trash2, Package, Save, Check, AlertTriangle, ImagePlus, X, ChevronDown, ChevronUp, Truck, MessageCircle, Pencil, Shirt, Ruler, Settings, MapPin, Building2 } from "lucide-react";

const STORAGE_KEY = "print-shop-inventory";
const LOGO_KEY = "print-shop-logo";
const THEME_KEY = "print-shop-theme";
const COMPANY_KEY = "print-shop-company";

// ערכות צבע לממשק
const THEMES = [
  { id: "classic", name: "קלאסי", accent: "#1c1c1a", pageBg: "#edece7" },
  { id: "blue", name: "כחול", accent: "#1e5fa8", pageBg: "#e7edf4" },
  { id: "green", name: "ירוק", accent: "#1a7f4e", pageBg: "#e8f0ea" },
  { id: "purple", name: "סגול", accent: "#6b3fa0", pageBg: "#efeaf4" },
  { id: "pink", name: "ורוד", accent: "#c2417f", pageBg: "#f6eaef" },
  { id: "orange", name: "כתום", accent: "#c46a08", pageBg: "#f6efe3" },
];

const DEFAULT_ITEMS = [
  { id: "1", name: "חולצות דרייפיט", qty: 0 },
  { id: "2", name: "גלילי מדבקה", qty: 0 },
  { id: "3", name: "מנורות לילה", qty: 0 },
  { id: "4", name: "שעון צבעוני", qty: 0 },
  { id: "5", name: "בוצ'רים", qty: 0 },
];

const LOW_STOCK = 5;

const SIZE_LIST = ["2", "4", "6", "8", "10", "12", "14", "16", "18", "S", "M", "L", "XL", "2XL", "3XL", "4XL"];

const WIDTH_LIST = ['105 ס"מ', '127 ס"מ', '158 ס"מ'];

const isShirtItem = (it) => it.name.includes("חולצ");

// הוספת קטגוריית שמשוניות אם עדיין לא קיימת ברשימה
const ensureShmashoniot = (list) => {
  if (list.some((it) => it.name.includes("שמשוני"))) return list;
  return [
    ...list,
    {
      id: "shmashoniot",
      name: "שמשוניות",
      qty: 0,
      variantType: "width",
      sizes: Object.fromEntries(WIDTH_LIST.map((w) => [w, 0])),
    },
  ];
};

// המרת מספר טלפון לפורמט בינלאומי עבור וואטסאפ (ברירת מחדל: ישראל)
const toWhatsAppNumber = (phone) => {
  let digits = phone.replace(/\D/g, "");
  if (digits.startsWith("0")) digits = "972" + digits.slice(1);
  return digits;
};

// --- צליל לחיצה ---
let audioCtx = null;
const playClick = () => {
  try {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === "suspended") audioCtx.resume();
    const t = audioCtx.currentTime;
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(900, t);
    osc.frequency.exponentialRampToValueAtTime(420, t + 0.07);
    gain.gain.setValueAtTime(0.16, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start(t);
    osc.stop(t + 0.1);
  } catch (e) {
    // אם הדפדפן חוסם שמע — פשוט בלי צליל
  }
};

// --- צליל אזהרה: כמות הגיעה לאפס ---
const playWarning = () => {
  try {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === "suspended") audioCtx.resume();
    const t = audioCtx.currentTime;
    // שני צפצופים נמוכים יורדים — צליל "שים לב"
    [0, 0.16].forEach((delay, idx) => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "square";
      osc.frequency.setValueAtTime(idx === 0 ? 330 : 220, t + delay);
      gain.gain.setValueAtTime(0.0001, t + delay);
      gain.gain.exponentialRampToValueAtTime(0.12, t + delay + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, t + delay + 0.14);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(t + delay);
      osc.stop(t + delay + 0.15);
    });
  } catch (e) {
    // אם הדפדפן חוסם שמע — ממשיכים בלי צליל
  }
};

// כמות כוללת: לחולצות — סכום המידות, לשאר — הכמות הרגילה
const getQty = (it) =>
  it.sizes
    ? Object.values(it.sizes).reduce((s, n) => s + (n || 0), 0)
    : it.qty;

// הוספת מבנה מידות לחולצות (גם לנתונים ישנים שנשמרו)
const withSizes = (it) =>
  isShirtItem(it) && !it.sizes
    ? { ...it, sizes: Object.fromEntries(SIZE_LIST.map((s) => [s, 0])) }
    : it;

export default function InventoryApp() {
  const [items, setItems] = useState(null);
  const [newName, setNewName] = useState("");
  const [newWithSizes, setNewWithSizes] = useState(false);
  const [saveState, setSaveState] = useState("idle"); // idle | saving | saved
  const [logo, setLogo] = useState(null);
  const [logoError, setLogoError] = useState("");
  const [expandedId, setExpandedId] = useState(null);
  const [supplierName, setSupplierName] = useState("");
  const [supplierPhone, setSupplierPhone] = useState("");
  const [editingSupplier, setEditingSupplier] = useState(null); // { itemId, supplierId }
  const [editName, setEditName] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const imageTargetId = useRef(null);
  const itemImageInputRef = useRef(null);
  const [hoveredImage, setHoveredImage] = useState(null); // { id, x, y, above }
  const [themeId, setThemeId] = useState("classic");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [company, setCompany] = useState({ name: "", hp: "", address: "" });
  const [companyOpen, setCompanyOpen] = useState(false);
  const [companyDraft, setCompanyDraft] = useState({ name: "", hp: "", address: "" });
  const fileInputRef = useRef(null);
  const saveTimer = useRef(null);
  const firstLoad = useRef(true);

  // טעינה ראשונית
  useEffect(() => {
    (async () => {
      try {
        const result = await window.storage.get(STORAGE_KEY);
        if (result && result.value) {
          setItems(ensureShmashoniot(JSON.parse(result.value).map(withSizes)));
        } else {
          setItems(ensureShmashoniot(DEFAULT_ITEMS.map(withSizes)));
        }
      } catch (e) {
        setItems(ensureShmashoniot(DEFAULT_ITEMS.map(withSizes)));
      }
      try {
        const logoResult = await window.storage.get(LOGO_KEY);
        if (logoResult && logoResult.value) setLogo(logoResult.value);
      } catch (e) {
        // אין לוגו שמור — זה בסדר
      }
      try {
        const themeResult = await window.storage.get(THEME_KEY);
        if (themeResult && themeResult.value) setThemeId(themeResult.value);
      } catch (e) {
        // אין ערכת צבע שמורה — נשארים בקלאסי
      }
      try {
        const companyResult = await window.storage.get(COMPANY_KEY);
        if (companyResult && companyResult.value) {
          setCompany(JSON.parse(companyResult.value));
        }
      } catch (e) {
        // אין פרטי חברה שמורים — זה בסדר
      }
    })();
  }, []);

  // שמירה אוטומטית עם השהיה קצרה
  useEffect(() => {
    if (items === null) return;
    if (firstLoad.current) {
      firstLoad.current = false;
      return;
    }
    setSaveState("saving");
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      try {
        await window.storage.set(STORAGE_KEY, JSON.stringify(items));
        setSaveState("saved");
        setTimeout(() => setSaveState("idle"), 1500);
      } catch (e) {
        setSaveState("idle");
      }
    }, 600);
    return () => clearTimeout(saveTimer.current);
  }, [items]);

  const changeQty = (id, delta) => {
    setItems((prev) =>
      prev.map((it) => {
        if (it.id !== id) return it;
        const newQty = Math.max(0, it.qty + delta);
        if (newQty === 0 && it.qty > 0) setTimeout(playWarning, 0);
        return { ...it, qty: newQty };
      })
    );
  };

  const setQty = (id, value) => {
    const num = Math.max(0, parseInt(value, 10) || 0);
    setItems((prev) =>
      prev.map((it) => {
        if (it.id !== id) return it;
        if (num === 0 && it.qty > 0) setTimeout(playWarning, 0);
        return { ...it, qty: num };
      })
    );
  };

  const removeItem = (id) => {
    setItems((prev) => prev.filter((it) => it.id !== id));
  };

  // הזזת מוצר למעלה או למטה ברשימה
  const moveItem = (id, direction) => {
    setItems((prev) => {
      const idx = prev.findIndex((it) => it.id === id);
      const target = idx + direction;
      if (idx === -1 || target < 0 || target >= prev.length) return prev;
      const next = [...prev];
      [next[idx], next[target]] = [next[target], next[idx]];
      return next;
    });
  };

  // --- ניהול ספקים ---
  const toggleExpand = (id) => {
    setExpandedId((prev) => (prev === id ? null : id));
    setSupplierName("");
    setSupplierPhone("");
    setEditingSupplier(null);
  };

  const addSupplier = (itemId) => {
    const name = supplierName.trim();
    if (!name) return;
    const supplier = {
      id: Date.now().toString(),
      name,
      phone: supplierPhone.trim(),
    };
    setItems((prev) =>
      prev.map((it) =>
        it.id === itemId
          ? { ...it, suppliers: [...(it.suppliers || []), supplier] }
          : it
      )
    );
    setSupplierName("");
    setSupplierPhone("");
  };

  const removeSupplier = (itemId, supplierId) => {
    setItems((prev) =>
      prev.map((it) =>
        it.id === itemId
          ? { ...it, suppliers: (it.suppliers || []).filter((s) => s.id !== supplierId) }
          : it
      )
    );
  };

  const startEditSupplier = (itemId, supplier) => {
    setEditingSupplier({ itemId, supplierId: supplier.id });
    setEditName(supplier.name);
    setEditPhone(supplier.phone || "");
  };

  const saveEditSupplier = () => {
    if (!editingSupplier) return;
    const name = editName.trim();
    if (!name) return;
    setItems((prev) =>
      prev.map((it) =>
        it.id === editingSupplier.itemId
          ? {
              ...it,
              suppliers: (it.suppliers || []).map((s) =>
                s.id === editingSupplier.supplierId
                  ? { ...s, name, phone: editPhone.trim() }
                  : s
              ),
            }
          : it
      )
    );
    setEditingSupplier(null);
  };

  const addItem = () => {
    const name = newName.trim();
    if (!name) return;
    const base = { id: Date.now().toString(), name, qty: 0 };
    const item = newWithSizes
      ? { ...base, sizes: Object.fromEntries(SIZE_LIST.map((s) => [s, 0])) }
      : withSizes(base);
    setItems((prev) => [...prev, item]);
    setNewName("");
    setNewWithSizes(false);
  };

  // --- כמויות לפי מידה (חולצות) ---
  const changeSizeQty = (itemId, size, delta) => {
    setItems((prev) =>
      prev.map((it) => {
        if (it.id !== itemId || !it.sizes) return it;
        const current = it.sizes[size] || 0;
        const newQty = Math.max(0, current + delta);
        if (newQty === 0 && current > 0) setTimeout(playWarning, 0);
        return { ...it, sizes: { ...it.sizes, [size]: newQty } };
      })
    );
  };

  const setSizeQty = (itemId, size, value) => {
    const num = Math.max(0, parseInt(value, 10) || 0);
    setItems((prev) =>
      prev.map((it) => {
        if (it.id !== itemId || !it.sizes) return it;
        const current = it.sizes[size] || 0;
        if (num === 0 && current > 0) setTimeout(playWarning, 0);
        return { ...it, sizes: { ...it.sizes, [size]: num } };
      })
    );
  };

  // העלאת לוגו: כיווץ התמונה ושמירה כ-Data URL
  const handleLogoUpload = (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setLogoError("יש לבחור קובץ תמונה (PNG, JPG וכדומה)");
      return;
    }
    setLogoError("");
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = async () => {
        // כיווץ לגודל סביר כדי שהשמירה תהיה קלה ומהירה
        const MAX = 240;
        const scale = Math.min(1, MAX / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL("image/png");
        setLogo(dataUrl);
        try {
          await window.storage.set(LOGO_KEY, dataUrl);
        } catch (err) {
          setLogoError("שמירת הלוגו נכשלה — נסו שוב");
        }
      };
      img.onerror = () => setLogoError("לא הצלחנו לקרוא את התמונה");
      img.src = reader.result;
    };
    reader.onerror = () => setLogoError("לא הצלחנו לקרוא את הקובץ");
    reader.readAsDataURL(file);
  };

  const removeLogo = async () => {
    setLogo(null);
    try {
      await window.storage.delete(LOGO_KEY);
    } catch (e) {
      // הלוגו כבר לא קיים — אין צורך בטיפול
    }
  };

  // --- ערכת צבע ---
  const selectTheme = async (id) => {
    setThemeId(id);
    try {
      await window.storage.set(THEME_KEY, id);
    } catch (e) {
      // השמירה נכשלה — הצבע יחול רק לסשן הנוכחי
    }
  };

  // --- פרטי החברה ---
  const openCompany = () => {
    setCompanyDraft({ ...company });
    setCompanyOpen(true);
  };

  const saveCompany = async () => {
    const cleaned = {
      name: companyDraft.name.trim(),
      hp: companyDraft.hp.trim(),
      address: companyDraft.address.trim(),
    };
    setCompany(cleaned);
    setCompanyOpen(false);
    try {
      await window.storage.set(COMPANY_KEY, JSON.stringify(cleaned));
    } catch (e) {
      // השמירה נכשלה — הפרטים יישארו רק לסשן הנוכחי
    }
  };

  // --- תמונת מוצר ---
  const openItemImagePicker = (itemId) => {
    imageTargetId.current = itemId;
    if (itemImageInputRef.current) itemImageInputRef.current.click();
  };

  const handleItemImageUpload = (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";
    const targetId = imageTargetId.current;
    if (!file || !targetId) return;
    if (!file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        // כיווץ לרזולוציה שמספיקה גם לתצוגה המוגדלת
        const MAX = 480;
        const scale = Math.min(1, MAX / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.82);
        setItems((prev) =>
          prev.map((it) => (it.id === targetId ? { ...it, image: dataUrl } : it))
        );
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  };

  const removeItemImage = (itemId) => {
    setItems((prev) =>
      prev.map((it) => {
        if (it.id !== itemId) return it;
        const { image, ...rest } = it;
        return rest;
      })
    );
  };

  if (items === null) {
    return (
      <div dir="rtl" style={styles.page}>
        <div style={{ ...styles.card, textAlign: "center", padding: 48, color: "#6b6b6b" }}>
          טוען את המלאי…
        </div>
      </div>
    );
  }

  const total = items.reduce((s, it) => s + getQty(it), 0);
  const lowCount = items.filter((it) => getQty(it) > 0 && getQty(it) <= LOW_STOCK).length;
  const outCount = items.filter((it) => getQty(it) === 0).length;
  const theme = THEMES.find((t) => t.id === themeId) || THEMES[0];

  return (
    <div
      dir="rtl"
      style={{ ...styles.page, background: theme.pageBg, transition: "background 0.4s ease" }}
      onClickCapture={(e) => {
        // צליל לחיצה לכל כפתור או קישור באפליקציה
        if (e.target.closest && e.target.closest("button, a")) playClick();
      }}
    >
      <div style={styles.container}>
        {/* כותרת */}
        <header style={styles.header}>
          <div style={styles.logoRow}>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleLogoUpload}
              style={{ display: "none" }}
            />
            <button
              style={{
                ...styles.logoBox,
                background: logo ? "#fffefb" : theme.accent,
                border: logo ? "1px solid #e2e1da" : "none",
                padding: 0,
                cursor: "pointer",
                transition: "background 0.4s ease",
              }}
              onClick={openCompany}
              title="פרטי החברה"
              aria-label="פתיחת פרטי החברה"
            >
              {logo ? (
                <img
                  src={logo}
                  alt="לוגו העסק"
                  style={{ width: "100%", height: "100%", objectFit: "contain", borderRadius: 17 }}
                />
              ) : (
                <Package size={38} color="#fff" strokeWidth={2.2} />
              )}
            </button>
            <div>
              <h1 style={styles.title}>{company.name || "מערכת מלאי"}</h1>
              <div style={styles.subtitle}>
                {company.name ? "מערכת מלאי" : "בית דפוס · ניהול מוצרים וכמויות"}
                {company.hp && ` · ח.פ ${company.hp}`}
              </div>
              {company.address && (
                <div style={styles.companyAddress}>
                  <MapPin size={12} />
                  {company.address}
                </div>
              )}
              <div style={styles.logoActions}>
                <button
                  style={styles.logoActionBtn}
                  onClick={() => fileInputRef.current && fileInputRef.current.click()}
                >
                  <ImagePlus size={13} />
                  {logo ? "החלפת לוגו" : "העלאת לוגו"}
                </button>
                {logo && (
                  <button style={styles.logoActionBtn} onClick={removeLogo}>
                    <X size={13} />
                    הסרה
                  </button>
                )}
              </div>
              {logoError && <div style={styles.logoError}>{logoError}</div>}
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10, position: "relative" }}>
            <div style={styles.saveBadge}>
              {saveState === "saving" && (
                <span style={{ color: "#a06a00", display: "flex", alignItems: "center", gap: 6 }}>
                  <Save size={15} /> שומר…
                </span>
              )}
              {saveState === "saved" && (
                <span style={{ color: "#1a7f4e", display: "flex", alignItems: "center", gap: 6 }}>
                  <Check size={15} /> נשמר
                </span>
              )}
            </div>
            <button
              style={{
                ...styles.settingsBtn,
                background: settingsOpen ? theme.accent : "#fffefb",
                color: settingsOpen ? "#fff" : "#5b5a54",
              }}
              onClick={() => setSettingsOpen((v) => !v)}
              title="הגדרות"
              aria-label="הגדרות"
              aria-expanded={settingsOpen}
            >
              <Settings size={19} />
            </button>
            {settingsOpen && (
              <div style={styles.settingsPanel}>
                <div style={styles.settingsTitle}>
                  <Settings size={14} />
                  צבע הממשק
                </div>
                <div style={styles.themeGrid}>
                  {THEMES.map((t) => (
                    <button
                      key={t.id}
                      style={{
                        ...styles.themeOption,
                        border:
                          t.id === themeId
                            ? `2px solid ${t.accent}`
                            : "2px solid #e2e1da",
                      }}
                      onClick={() => selectTheme(t.id)}
                      aria-pressed={t.id === themeId}
                    >
                      <span
                        style={{
                          ...styles.themeSwatch,
                          background: `linear-gradient(135deg, ${t.accent} 50%, ${t.pageBg} 50%)`,
                        }}
                      >
                        {t.id === themeId && <Check size={14} color="#fff" />}
                      </span>
                      <span style={styles.themeName}>{t.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </header>

        {/* חלון פרטי החברה */}
        {companyOpen && (
          <div style={styles.modalOverlay} onClick={() => setCompanyOpen(false)}>
            <div style={styles.modalCard} onClick={(e) => e.stopPropagation()}>
              <div style={styles.modalHeader}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <Building2 size={18} color={theme.accent} />
                  <span style={{ fontSize: 17, fontWeight: 800, color: "#1c1c1a" }}>
                    פרטי החברה
                  </span>
                </div>
                <button
                  style={styles.supplierIconBtn}
                  onClick={() => setCompanyOpen(false)}
                  aria-label="סגירה"
                >
                  <X size={18} />
                </button>
              </div>

              <label style={styles.modalLabel}>שם החברה</label>
              <input
                value={companyDraft.name}
                onChange={(e) => setCompanyDraft((d) => ({ ...d, name: e.target.value }))}
                placeholder='למשל: דפוס האחים בע"מ'
                style={styles.modalInput}
                autoFocus
              />

              <label style={styles.modalLabel}>מס' ח.פ</label>
              <input
                value={companyDraft.hp}
                onChange={(e) => setCompanyDraft((d) => ({ ...d, hp: e.target.value }))}
                placeholder="למשל: 515123456"
                style={styles.modalInput}
                inputMode="numeric"
              />

              <label style={styles.modalLabel}>כתובת</label>
              <input
                value={companyDraft.address}
                onChange={(e) => setCompanyDraft((d) => ({ ...d, address: e.target.value }))}
                placeholder="למשל: רחוב הדפוס 12, ירושלים"
                style={styles.modalInput}
                onKeyDown={(e) => e.key === "Enter" && saveCompany()}
              />

              <div style={styles.modalActions}>
                <button
                  style={{ ...styles.addBtn, background: theme.accent, height: 42, padding: "0 22px" }}
                  onClick={saveCompany}
                >
                  <Check size={17} />
                  שמירה
                </button>
                <button style={styles.modalCancelBtn} onClick={() => setCompanyOpen(false)}>
                  ביטול
                </button>
              </div>
            </div>
          </div>
        )}

        {/* סיכום */}
        <div style={styles.statsRow}>
          <div style={styles.statCard}>
            <div style={styles.statNum}>{items.length}</div>
            <div style={styles.statLabel}>סוגי מוצרים</div>
          </div>
          <div style={styles.statCard}>
            <div style={styles.statNum}>{total.toLocaleString("he-IL")}</div>
            <div style={styles.statLabel}>סה"כ יחידות</div>
          </div>
          <div style={{ ...styles.statCard, background: outCount > 0 ? "#fdf0ef" : "#f6f6f3" }}>
            <div style={{ ...styles.statNum, color: outCount > 0 ? "#c0392b" : "#1c1c1a" }}>
              {outCount}
            </div>
            <div style={styles.statLabel}>אזל מהמלאי</div>
          </div>
          <div style={{ ...styles.statCard, background: lowCount > 0 ? "#fdf6ea" : "#f6f6f3" }}>
            <div style={{ ...styles.statNum, color: lowCount > 0 ? "#a06a00" : "#1c1c1a" }}>
              {lowCount}
            </div>
            <div style={styles.statLabel}>מלאי נמוך</div>
          </div>
        </div>

        {/* רשימת מוצרים */}
        <input
          ref={itemImageInputRef}
          type="file"
          accept="image/*"
          onChange={handleItemImageUpload}
          style={{ display: "none" }}
        />
        <div style={styles.card}>
          {items.length === 0 && (
            <div style={{ padding: 40, textAlign: "center", color: "#8a8a85" }}>
              אין מוצרים ברשימה. הוסיפו מוצר חדש למטה.
            </div>
          )}
          {items.map((it, i) => {
            const qty = getQty(it);
            const isOut = qty === 0;
            const isLow = qty > 0 && qty <= LOW_STOCK;
            const isOpen = expandedId === it.id;
            const suppliers = it.suppliers || [];
            const hasSizes = !!it.sizes;
            return (
              <div key={it.id}>
                <div
                  style={{
                    ...styles.row,
                    borderBottom:
                      !isOpen && i < items.length - 1 ? "1px solid #ebebe6" : "none",
                    background: isOut
                      ? "#fbe3e0"
                      : isLow
                      ? "#fcecd2"
                      : isOpen
                      ? "#fafaf6"
                      : "transparent",
                    borderRight: isOut
                      ? "4px solid #c0392b"
                      : isLow
                      ? "4px solid #e08a00"
                      : "4px solid transparent",
                  }}
                >
                  <div
                    style={{ position: "relative", flexShrink: 0 }}
                    onMouseEnter={(e) => {
                      if (!it.image) return;
                      const rect = e.currentTarget.getBoundingClientRect();
                      const PREVIEW = 280;
                      // מציבים מתחת לתמונה, ואם אין מקום — מעליה
                      const above = rect.bottom + PREVIEW + 16 > window.innerHeight;
                      const x = Math.min(
                        Math.max(8, rect.left + rect.width / 2 - PREVIEW / 2),
                        window.innerWidth - PREVIEW - 8
                      );
                      const y = above ? rect.top - PREVIEW - 10 : rect.bottom + 10;
                      setHoveredImage({ id: it.id, x, y });
                    }}
                    onMouseLeave={() => setHoveredImage(null)}
                  >
                    <button
                      style={styles.itemImageBtn}
                      onClick={() => openItemImagePicker(it.id)}
                      title={it.image ? "החלפת תמונת המוצר" : "הוספת תמונה למוצר"}
                      aria-label={it.image ? `החלפת תמונת ${it.name}` : `הוספת תמונה ל${it.name}`}
                    >
                      {it.image ? (
                        <img
                          src={it.image}
                          alt={it.name}
                          style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: 10 }}
                        />
                      ) : (
                        <ImagePlus size={18} color="#b3b2aa" />
                      )}
                    </button>
                    {hoveredImage && hoveredImage.id === it.id && it.image && (
                      <div
                        style={{
                          ...styles.imagePreview,
                          left: hoveredImage.x,
                          top: hoveredImage.y,
                        }}
                      >
                        <img
                          src={it.image}
                          alt={it.name}
                          style={{
                            width: "100%",
                            flex: 1,
                            minHeight: 0,
                            objectFit: "contain",
                            borderRadius: 14,
                          }}
                        />
                        <div style={styles.imagePreviewName}>{it.name}</div>
                      </div>
                    )}
                  </div>
                  <button
                    style={styles.itemToggle}
                    onClick={() => toggleExpand(it.id)}
                    aria-expanded={isOpen}
                    aria-label={`ספקים עבור ${it.name}`}
                  >
                    <ChevronDown
                      size={18}
                      style={{
                        transform: isOpen ? "rotate(180deg)" : "rotate(0deg)",
                        transition: "transform 0.2s",
                        color: "#8a8a85",
                        flexShrink: 0,
                      }}
                    />
                    <div style={{ minWidth: 0 }}>
                      <div style={styles.itemName}>{it.name}</div>
                      <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                        {isOut && (
                          <div style={{ ...styles.tag, color: "#c0392b" }}>
                            <AlertTriangle size={12} /> אזל מהמלאי
                          </div>
                        )}
                        {isLow && (
                          <div style={{ ...styles.tag, color: "#a06a00" }}>
                            <AlertTriangle size={12} /> מלאי נמוך
                          </div>
                        )}
                        <div style={{ ...styles.tag, color: "#76756f" }}>
                          <Truck size={12} />
                          {suppliers.length > 0
                            ? `${suppliers.length} ספקים`
                            : "אין ספקים"}
                        </div>
                      </div>
                    </div>
                  </button>

                  {hasSizes ? (
                    <button style={styles.sizesTotalBadge} onClick={() => toggleExpand(it.id)}>
                      {it.variantType === "width" ? <Ruler size={15} /> : <Shirt size={15} />}
                      <span style={{ fontSize: 18, fontWeight: 800 }}>{qty}</span>
                      <span style={{ fontSize: 12, fontWeight: 600 }}>
                        {it.variantType === "width" ? "יח' · לפי רוחב" : "יח' · לפי מידות"}
                      </span>
                    </button>
                  ) : (
                    <div style={styles.qtyControls}>
                      <button
                        style={styles.qtyBtn}
                        onClick={() => changeQty(it.id, -1)}
                        aria-label="הפחתת יחידה"
                      >
                        <Minus size={16} />
                      </button>
                      <input
                        type="number"
                        min="0"
                        value={it.qty}
                        onChange={(e) => setQty(it.id, e.target.value)}
                        style={styles.qtyInput}
                        aria-label={`כמות ${it.name}`}
                      />
                      <button
                        style={styles.qtyBtn}
                        onClick={() => changeQty(it.id, 1)}
                        aria-label="הוספת יחידה"
                      >
                        <Plus size={16} />
                      </button>
                      <button
                        style={styles.qtyBtnFast}
                        onClick={() => changeQty(it.id, 10)}
                        title="הוספת 10 יחידות"
                      >
                        ‎+10
                      </button>
                    </div>
                  )}

                  <div style={styles.moveButtons}>
                    <button
                      style={{
                        ...styles.moveBtn,
                        opacity: i === 0 ? 0.25 : 1,
                        cursor: i === 0 ? "default" : "pointer",
                      }}
                      onClick={() => moveItem(it.id, -1)}
                      disabled={i === 0}
                      title="הזזה למעלה"
                      aria-label={`הזזת ${it.name} למעלה`}
                    >
                      <ChevronUp size={12} />
                    </button>
                    <button
                      style={{
                        ...styles.moveBtn,
                        opacity: i === items.length - 1 ? 0.25 : 1,
                        cursor: i === items.length - 1 ? "default" : "pointer",
                      }}
                      onClick={() => moveItem(it.id, 1)}
                      disabled={i === items.length - 1}
                      title="הזזה למטה"
                      aria-label={`הזזת ${it.name} למטה`}
                    >
                      <ChevronDown size={12} />
                    </button>
                  </div>

                  <button
                    style={styles.deleteBtn}
                    onClick={() => removeItem(it.id)}
                    aria-label={`מחיקת ${it.name}`}
                    title="מחיקת מוצר"
                  >
                    <Trash2 size={17} />
                  </button>
                </div>

                {/* פאנל ספקים — נפתח בהנפשה חלקה */}
                <div
                  style={{
                    display: "grid",
                    gridTemplateRows: isOpen ? "1fr" : "0fr",
                    transition: "grid-template-rows 0.35s cubic-bezier(0.4, 0, 0.2, 1)",
                    borderBottom:
                      isOpen && i < items.length - 1 ? "1px solid #ebebe6" : "none",
                  }}
                >
                  <div style={{ overflow: "hidden", minHeight: 0 }}>
                    <div
                      style={{
                        ...styles.supplierPanel,
                        opacity: isOpen ? 1 : 0,
                        transform: isOpen ? "translateY(0)" : "translateY(-8px)",
                        transition: "opacity 0.3s ease 0.05s, transform 0.35s ease",
                      }}
                    >
                    {hasSizes && (
                      <>
                        <div style={styles.supplierHeader}>
                          {it.variantType === "width" ? <Ruler size={15} /> : <Shirt size={15} />}
                          {it.variantType === "width"
                            ? `כמויות לפי רוחב גליל · סה"כ ${qty} יחידות`
                            : `כמויות לפי מידה · סה"כ ${qty} יחידות`}
                        </div>
                        <div style={styles.sizesGrid}>
                          {Object.keys(it.sizes).map((size) => {
                            const sq = it.sizes[size] || 0;
                            return (
                              <div
                                key={size}
                                style={{
                                  ...styles.sizeCell,
                                  background:
                                    sq === 0 ? "#fbe3e0" : sq <= LOW_STOCK ? "#fcecd2" : "#fffefb",
                                }}
                              >
                                <div style={styles.sizeLabel}>{size}</div>
                                <div style={styles.sizeControls}>
                                  <button
                                    style={styles.sizeBtn}
                                    onClick={() => changeSizeQty(it.id, size, -1)}
                                    aria-label={`הפחתה ממידה ${size}`}
                                  >
                                    <Minus size={13} />
                                  </button>
                                  <input
                                    type="number"
                                    min="0"
                                    value={sq}
                                    onChange={(e) => setSizeQty(it.id, size, e.target.value)}
                                    style={styles.sizeInput}
                                    aria-label={`כמות מידה ${size}`}
                                  />
                                  <button
                                    style={styles.sizeBtn}
                                    onClick={() => changeSizeQty(it.id, size, 1)}
                                    aria-label={`הוספה למידה ${size}`}
                                  >
                                    <Plus size={13} />
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </>
                    )}

                    <div style={styles.supplierHeader}>
                      <Truck size={15} />
                      ספקים להזמנת {it.name}
                      <span style={{ flex: 1 }} />
                      <button
                        style={styles.logoActionBtn}
                        onClick={() => openItemImagePicker(it.id)}
                      >
                        <ImagePlus size={13} />
                        {it.image ? "החלפת תמונה" : "הוספת תמונה"}
                      </button>
                      {it.image && (
                        <button
                          style={styles.logoActionBtn}
                          onClick={() => removeItemImage(it.id)}
                        >
                          <X size={13} />
                          הסרת תמונה
                        </button>
                      )}
                    </div>

                    {suppliers.length === 0 && (
                      <div style={styles.supplierEmpty}>
                        עדיין לא הוספתם ספקים למוצר הזה
                      </div>
                    )}

                    {suppliers.map((s) => {
                      const isEditing =
                        editingSupplier &&
                        editingSupplier.itemId === it.id &&
                        editingSupplier.supplierId === s.id;
                      return (
                        <div key={s.id} style={styles.supplierRow}>
                          {isEditing ? (
                            <>
                              <input
                                value={editName}
                                onChange={(e) => setEditName(e.target.value)}
                                onKeyDown={(e) => e.key === "Enter" && saveEditSupplier()}
                                placeholder="שם הספק"
                                style={{ ...styles.supplierInput, flex: 1.4 }}
                                autoFocus
                              />
                              <input
                                value={editPhone}
                                onChange={(e) => setEditPhone(e.target.value)}
                                onKeyDown={(e) => e.key === "Enter" && saveEditSupplier()}
                                placeholder="טלפון / הערה"
                                style={{ ...styles.supplierInput, flex: 1 }}
                              />
                              <button
                                style={{ ...styles.supplierIconBtn, color: "#1a7f4e" }}
                                onClick={saveEditSupplier}
                                title="שמירה"
                                aria-label="שמירת ספק"
                              >
                                <Check size={16} />
                              </button>
                              <button
                                style={styles.supplierIconBtn}
                                onClick={() => setEditingSupplier(null)}
                                title="ביטול"
                                aria-label="ביטול עריכה"
                              >
                                <X size={16} />
                              </button>
                            </>
                          ) : (
                            <>
                              <div style={{ flex: 1, minWidth: 0 }}>
                                <div style={styles.supplierName}>{s.name}</div>
                                {s.phone && (
                                  <a
                                    href={`https://wa.me/${toWhatsAppNumber(s.phone)}?text=${encodeURIComponent(
                                      `שלום ${s.name}, אשמח להזמין ${it.name}`
                                    )}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    style={styles.supplierPhone}
                                    title="שליחת הודעה בוואטסאפ"
                                  >
                                    <MessageCircle size={13} />
                                    {s.phone}
                                  </a>
                                )}
                              </div>
                              <button
                                style={styles.supplierIconBtn}
                                onClick={() => startEditSupplier(it.id, s)}
                                title="עריכת ספק"
                                aria-label={`עריכת ${s.name}`}
                              >
                                <Pencil size={15} />
                              </button>
                              <button
                                style={styles.supplierIconBtn}
                                onClick={() => removeSupplier(it.id, s.id)}
                                title="מחיקת ספק"
                                aria-label={`מחיקת ${s.name}`}
                              >
                                <Trash2 size={15} />
                              </button>
                            </>
                          )}
                        </div>
                      );
                    })}

                    {/* הוספת ספק */}
                    <div style={styles.supplierAddRow}>
                      <input
                        value={supplierName}
                        onChange={(e) => setSupplierName(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && addSupplier(it.id)}
                        placeholder="שם הספק"
                        style={{ ...styles.supplierInput, flex: 1.4 }}
                      />
                      <input
                        value={supplierPhone}
                        onChange={(e) => setSupplierPhone(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && addSupplier(it.id)}
                        placeholder="טלפון / הערה (לא חובה)"
                        style={{ ...styles.supplierInput, flex: 1 }}
                      />
                      <button
                        style={{
                          ...styles.supplierAddBtn,
                          background: theme.accent,
                          opacity: supplierName.trim() ? 1 : 0.5,
                          cursor: supplierName.trim() ? "pointer" : "default",
                        }}
                        onClick={() => addSupplier(it.id)}
                      >
                        <Plus size={15} />
                        הוספה
                      </button>
                    </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* הוספת מוצר */}
        <div style={styles.addRow}>
          <input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addItem()}
            placeholder="שם מוצר חדש, למשל: כוסות ממותגות"
            style={styles.addInput}
          />
          <button
            onClick={() => setNewWithSizes((v) => !v)}
            style={{
              ...styles.sizesToggleBtn,
              background: newWithSizes ? theme.accent : "#f6f6f3",
              color: newWithSizes ? "#fff" : "#5b5a54",
              border: newWithSizes ? `1px solid ${theme.accent}` : "1px solid #d8d7cf",
            }}
            title="המוצר ינוהל לפי מידות (2–18, S–4XL) כמו החולצות"
            aria-pressed={newWithSizes}
          >
            <Shirt size={16} />
            עם מידות
            {newWithSizes && <Check size={15} />}
          </button>
          <button
            onClick={addItem}
            style={{
              ...styles.addBtn,
              background: theme.accent,
              opacity: newName.trim() ? 1 : 0.5,
              cursor: newName.trim() ? "pointer" : "default",
            }}
          >
            <Plus size={18} />
            הוספת מוצר
          </button>
        </div>
        {newWithSizes && (
          <div style={styles.sizesHint}>
            המוצר החדש יקבל ניהול כמויות לפי מידות: {SIZE_LIST.join(", ")}
          </div>
        )}

        <div style={styles.footerNote}>
          השינויים נשמרים אוטומטית · מוצר עם {LOW_STOCK} יחידות או פחות מסומן כמלאי נמוך
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "#edece7",
    fontFamily: "'Heebo', 'Rubik', 'Segoe UI', system-ui, sans-serif",
    padding: "24px 14px",
    direction: "rtl",
  },
  container: { maxWidth: 680, margin: "0 auto" },
  header: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 18,
    flexWrap: "wrap",
    gap: 8,
  },
  logoRow: { display: "flex", alignItems: "center", gap: 14 },
  logoBox: {
    width: 84,
    height: 84,
    borderRadius: 18,
    background: "#1c1c1a",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    boxShadow: "0 4px 12px rgba(0,0,0,0.12)",
    overflow: "hidden",
    flexShrink: 0,
  },
  logoActions: { display: "flex", gap: 8, marginTop: 6 },
  logoActionBtn: {
    display: "flex",
    alignItems: "center",
    gap: 4,
    fontSize: 12,
    fontWeight: 600,
    color: "#76756f",
    background: "#f6f6f3",
    border: "1px solid #e2e1da",
    borderRadius: 8,
    padding: "4px 9px",
    cursor: "pointer",
    fontFamily: "inherit",
  },
  logoError: { fontSize: 12, color: "#c0392b", marginTop: 4, fontWeight: 600 },
  title: { margin: 0, fontSize: 26, fontWeight: 800, color: "#1c1c1a", letterSpacing: "-0.3px" },
  subtitle: { fontSize: 13.5, color: "#76756f", marginTop: 2 },
  companyAddress: {
    display: "flex",
    alignItems: "center",
    gap: 4,
    fontSize: 12.5,
    color: "#8a8a85",
    marginTop: 3,
  },
  modalOverlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(28, 28, 26, 0.45)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 500,
    padding: 16,
  },
  modalCard: {
    width: "100%",
    maxWidth: 420,
    background: "#fffefb",
    borderRadius: 20,
    boxShadow: "0 24px 60px rgba(0,0,0,0.3)",
    padding: 22,
  },
  modalHeader: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 14,
  },
  modalLabel: {
    display: "block",
    fontSize: 13,
    fontWeight: 700,
    color: "#5b5a54",
    marginBottom: 5,
    marginTop: 12,
  },
  modalInput: {
    width: "100%",
    height: 44,
    padding: "0 14px",
    fontSize: 15,
    border: "1px solid #d8d7cf",
    borderRadius: 12,
    background: "#fffefb",
    color: "#1c1c1a",
    outline: "none",
    fontFamily: "inherit",
    boxSizing: "border-box",
  },
  modalActions: { display: "flex", gap: 10, marginTop: 20 },
  modalCancelBtn: {
    height: 42,
    padding: "0 18px",
    fontSize: 14.5,
    fontWeight: 700,
    border: "1px solid #d8d7cf",
    borderRadius: 13,
    background: "#f6f6f3",
    color: "#5b5a54",
    cursor: "pointer",
    fontFamily: "inherit",
  },
  saveBadge: { fontSize: 13.5, fontWeight: 600, minHeight: 20 },
  settingsBtn: {
    width: 42,
    height: 42,
    borderRadius: 12,
    border: "1px solid #d8d7cf",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    transition: "background 0.25s ease, color 0.25s ease",
    flexShrink: 0,
  },
  settingsPanel: {
    position: "absolute",
    top: 50,
    left: 0,
    width: 250,
    background: "#fffefb",
    border: "1px solid #e2e1da",
    borderRadius: 16,
    boxShadow: "0 14px 38px rgba(0,0,0,0.18)",
    padding: 14,
    zIndex: 200,
  },
  settingsTitle: {
    display: "flex",
    alignItems: "center",
    gap: 6,
    fontSize: 13.5,
    fontWeight: 800,
    color: "#1c1c1a",
    marginBottom: 10,
  },
  themeGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr 1fr",
    gap: 8,
  },
  themeOption: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 5,
    padding: "8px 4px",
    borderRadius: 12,
    background: "#fafaf6",
    cursor: "pointer",
    fontFamily: "inherit",
  },
  themeSwatch: {
    width: 34,
    height: 34,
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.08)",
  },
  themeName: { fontSize: 12, fontWeight: 700, color: "#5b5a54" },
  statsRow: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(120px, 1fr))",
    gap: 10,
    marginBottom: 18,
  },
  statCard: {
    background: "#f6f6f3",
    border: "1px solid #e2e1da",
    borderRadius: 14,
    padding: "14px 16px",
    textAlign: "center",
  },
  statNum: { fontSize: 24, fontWeight: 800, color: "#1c1c1a", lineHeight: 1.1 },
  statLabel: { fontSize: 12.5, color: "#76756f", marginTop: 4 },
  card: {
    background: "#fffefb",
    border: "1px solid #e2e1da",
    borderRadius: 18,
    overflow: "hidden",
    boxShadow: "0 2px 10px rgba(0,0,0,0.05)",
  },
  row: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    padding: "16px 18px",
    flexWrap: "wrap",
    transition: "background 0.3s ease, border-right-color 0.3s ease",
  },
  itemName: { fontSize: 16.5, fontWeight: 700, color: "#1c1c1a" },
  itemImageBtn: {
    width: 46,
    height: 46,
    borderRadius: 11,
    border: "1px dashed #d8d7cf",
    background: "#f6f6f3",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    padding: 0,
    overflow: "hidden",
    flexShrink: 0,
  },
  imagePreview: {
    position: "fixed",
    width: 280,
    height: 280,
    background: "#fffefb",
    border: "1px solid #e2e1da",
    borderRadius: 16,
    boxShadow: "0 18px 48px rgba(0,0,0,0.28)",
    padding: 10,
    zIndex: 9999,
    pointerEvents: "none",
    display: "flex",
    flexDirection: "column",
  },
  imagePreviewName: {
    textAlign: "center",
    fontSize: 13.5,
    fontWeight: 700,
    color: "#1c1c1a",
    paddingTop: 6,
  },
  itemToggle: {
    flex: 1,
    minWidth: 130,
    display: "flex",
    alignItems: "center",
    gap: 10,
    background: "transparent",
    border: "none",
    padding: 0,
    cursor: "pointer",
    textAlign: "right",
    fontFamily: "inherit",
  },
  supplierPanel: {
    background: "#fafaf6",
    padding: "4px 22px 16px 22px",
    borderTop: "1px dashed #e2e1da",
  },
  supplierHeader: {
    display: "flex",
    alignItems: "center",
    gap: 6,
    fontSize: 13,
    fontWeight: 700,
    color: "#76756f",
    margin: "10px 0 8px 0",
  },
  supplierEmpty: { fontSize: 13.5, color: "#9a9992", padding: "6px 0 10px 0" },
  supplierRow: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    background: "#fffefb",
    border: "1px solid #e8e7e0",
    borderRadius: 11,
    padding: "9px 12px",
    marginBottom: 7,
  },
  supplierName: { fontSize: 14.5, fontWeight: 700, color: "#1c1c1a" },
  supplierPhone: {
    display: "inline-flex",
    alignItems: "center",
    gap: 4,
    fontSize: 12.5,
    color: "#1a8f4e",
    marginTop: 2,
    textDecoration: "none",
    fontWeight: 700,
  },
  supplierIconBtn: {
    width: 30,
    height: 30,
    borderRadius: 8,
    border: "none",
    background: "transparent",
    color: "#9a9992",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    flexShrink: 0,
  },
  supplierAddRow: { display: "flex", gap: 7, marginTop: 4, flexWrap: "wrap" },
  supplierInput: {
    minWidth: 120,
    height: 38,
    padding: "0 12px",
    fontSize: 13.5,
    border: "1px solid #d8d7cf",
    borderRadius: 10,
    background: "#fffefb",
    color: "#1c1c1a",
    outline: "none",
    fontFamily: "inherit",
  },
  supplierAddBtn: {
    height: 38,
    padding: "0 14px",
    display: "flex",
    alignItems: "center",
    gap: 5,
    fontSize: 13.5,
    fontWeight: 700,
    border: "none",
    borderRadius: 10,
    background: "#1c1c1a",
    color: "#fff",
    fontFamily: "inherit",
  },
  tag: {
    display: "inline-flex",
    alignItems: "center",
    gap: 4,
    fontSize: 12,
    fontWeight: 600,
    marginTop: 3,
  },
  qtyControls: { display: "flex", alignItems: "center", gap: 6 },
  sizesTotalBadge: {
    display: "flex",
    alignItems: "center",
    gap: 7,
    height: 40,
    padding: "0 14px",
    borderRadius: 11,
    border: "1px solid #d8d7cf",
    background: "#fffefb",
    color: "#1c1c1a",
    cursor: "pointer",
    fontFamily: "inherit",
  },
  sizesGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(118px, 1fr))",
    gap: 8,
    marginBottom: 16,
  },
  sizeCell: {
    border: "1px solid #e8e7e0",
    borderRadius: 11,
    padding: "8px 8px 9px 8px",
    textAlign: "center",
  },
  sizeLabel: { fontSize: 13.5, fontWeight: 800, color: "#1c1c1a", marginBottom: 6 },
  sizeControls: { display: "flex", alignItems: "center", justifyContent: "center", gap: 4 },
  sizeBtn: {
    width: 26,
    height: 28,
    borderRadius: 8,
    border: "1px solid #d8d7cf",
    background: "#f6f6f3",
    color: "#1c1c1a",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    flexShrink: 0,
    padding: 0,
  },
  sizeInput: {
    width: 40,
    height: 28,
    textAlign: "center",
    fontSize: 13.5,
    fontWeight: 700,
    border: "1px solid #d8d7cf",
    borderRadius: 8,
    background: "#fff",
    color: "#1c1c1a",
    outline: "none",
  },
  qtyBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    border: "1px solid #d8d7cf",
    background: "#f6f6f3",
    color: "#1c1c1a",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
  },
  qtyBtnFast: {
    height: 36,
    padding: "0 10px",
    borderRadius: 10,
    border: "1px solid #d8d7cf",
    background: "#f6f6f3",
    color: "#1c1c1a",
    fontSize: 13.5,
    fontWeight: 700,
    cursor: "pointer",
  },
  qtyInput: {
    width: 64,
    height: 36,
    textAlign: "center",
    fontSize: 16,
    fontWeight: 700,
    border: "1px solid #d8d7cf",
    borderRadius: 10,
    background: "#fff",
    color: "#1c1c1a",
    outline: "none",
  },
  deleteBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    border: "none",
    background: "transparent",
    color: "#b3b2aa",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
  },
  moveButtons: {
    display: "flex",
    flexDirection: "column",
    gap: 2,
    flexShrink: 0,
  },
  moveBtn: {
    width: 20,
    height: 16,
    borderRadius: 5,
    border: "1px solid #d8d7cf",
    background: "#f6f6f3",
    color: "#5b5a54",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 0,
  },
  addRow: { display: "flex", gap: 10, marginTop: 16, flexWrap: "wrap" },
  sizesToggleBtn: {
    height: 46,
    padding: "0 16px",
    display: "flex",
    alignItems: "center",
    gap: 7,
    fontSize: 14,
    fontWeight: 700,
    borderRadius: 13,
    cursor: "pointer",
    fontFamily: "inherit",
    transition: "background 0.2s ease, color 0.2s ease",
  },
  sizesHint: {
    fontSize: 12.5,
    color: "#76756f",
    marginTop: 8,
    paddingRight: 4,
  },
  addInput: {
    flex: 1,
    minWidth: 220,
    height: 46,
    padding: "0 16px",
    fontSize: 15,
    border: "1px solid #d8d7cf",
    borderRadius: 13,
    background: "#fffefb",
    color: "#1c1c1a",
    outline: "none",
    fontFamily: "inherit",
  },
  addBtn: {
    height: 46,
    padding: "0 20px",
    display: "flex",
    alignItems: "center",
    gap: 8,
    fontSize: 15,
    fontWeight: 700,
    border: "none",
    borderRadius: 13,
    background: "#1c1c1a",
    color: "#fff",
    fontFamily: "inherit",
  },
  footerNote: {
    textAlign: "center",
    fontSize: 12.5,
    color: "#8a8a85",
    marginTop: 16,
  },
};
